DROP DATABASE if exists Assignment3;
CREATE DATABASE Assignment3;
USE Assignment3;


CREATE TABLE Users(
    email VARCHAR(50) PRIMARY KEY NOT NULL,
    userImage VARCHAR(200) NOT NULL,
    userName VARCHAR(200) NOT NULL
);


CREATE TABLE Calendar(
	email VARCHAR(50) PRIMARY KEY NOT NULL,
   dateTimeStr VARCHAR (70) NOT NULL,
    _summary VARCHAR(200) NOT NULL,
     FOREIGN KEY fk1(email) REFERENCES Users(email)
);

CREATE TABLE Friends(
    email VARCHAR(50) PRIMARY KEY NOT NULL ,
    _name VARCHAR(50) NOT NULL,
    FOREIGN KEY fk2(email) REFERENCES Users(email)   
);

