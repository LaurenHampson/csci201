package csci201;

import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.google.api.client.util.DateTime;
import com.google.api.services.calendar.model.Event;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCDriver {
	private static Connection conn = null;
	private static ResultSet rs = null;
	private static Statement st = null;
	private static PreparedStatement ps = null;
	
	public static void connect(){
		try {
			Class.forName("com.mysql.cj.jdbc.Driver"); // for version 5 get rid of the .cj

			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Assignment3?user=root&password=root&useSSL=false");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void close(){
		try{
			if (rs!=null){
				rs.close();
				rs = null;
			}
			if(conn != null){
				conn.close();
				conn = null;
			}
			if(ps != null ){
				ps = null;
			}
		}catch(SQLException sqle){
			System.out.println("connection close error");
			sqle.printStackTrace();
		}
	}
	public static void addUser(String email, String userImage, String userName )
	{
		connect();
		try{
			 
		
			System.out.println("Connected database successfully...");
			ps = conn.prepareStatement("INSERT INTO Users (email, userImage, userName) VALUES ('" + email + "', '"
					+ userImage + "', '" + userName + "');");
			ps.executeUpdate();
		
		System.out.println("Inserted in try1");}
		catch(SQLException e)
		{
			System.out.println("SQLException in function \"addUser\"");
			e.printStackTrace();
		}finally {
			close();
		}
		
	}
	
	public static void addEvents(String email, List<Event> ev)
	{
		connect();
		 System.out.println("addEvents");

		try{
			 ps = conn.prepareStatement("DELETE FROM Calendar WHERE email = '" + email + "';");
			 ps.executeUpdate();
			 System.out.println("Trying");
			 for(int i = 0; i < ev.size(); i++)
			 {
				 				
						DateTime start = ev.get(i).getStart().getDateTime();
						
						//System.out.print(email + "-->" + dtStr + "--> " + summary);
						ps = conn.prepareStatement("INSERT INTO Calendar (email, dateTimeStr, _summary) VALUES ('" + email + "', '"
								+ start.toString()+"', '"+ ev.get(i).getSummary()+ "');");
						ps.executeUpdate();

						
					}
				
			 
			
		System.out.println("Inserted in try2");
		}
		catch(SQLException e)
		{
			System.out.println("SQLException in function \"addEvents\"");
			e.printStackTrace();
		}finally {
			close();
		}
	}
	
	
	public static void addFriend(String [] args)
	{}
	
	
	public static void printEvents(String [] args)
	{}
	
	
	public static ArrayList<ArrayList<String> > searchResults(String search)
	{
		ArrayList<ArrayList<String> > result = new ArrayList<ArrayList<String> >();
		connect();
		try {
			ps = conn.prepareStatement("SELECT u.userName, u.userImage FROM Users u WHERE u.userName LIKE \"%" + search + "%\"");
			rs = ps.executeQuery();
		
			while(rs.next())
			{
				ArrayList<String> row = new ArrayList<String>();
				row.add(rs.getString("u.userName"));
				System.out.println(rs.getString("u.userName"));
				row.add(rs.getString("u.userImage"));
				System.out.println(rs.getString("u.userImage"));

				result.add(row);
			}
		}catch(SQLException e)
			{
				System.out.println("SQLException in function \"addEvents\"");
				e.printStackTrace();
			}finally {
				close();
			}
		return result;
	}
	
	
	
}



