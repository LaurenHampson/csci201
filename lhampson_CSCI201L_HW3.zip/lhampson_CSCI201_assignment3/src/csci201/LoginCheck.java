package csci201;

import java.io.IOException;
import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.auth.oauth2.TokenResponse;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.DateTime;
import com.google.api.client.util.store.MemoryDataStoreFactory;
import com.google.api.services.calendar.Calendar;
import com.google.api.services.calendar.Calendar.Events;
import com.google.api.services.calendar.CalendarScopes;
import com.google.api.services.calendar.model.Event;
import com.google.api.services.calendar.model.EventDateTime;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.Statement;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.*;

/**
 * 
 * Servlet implementation class LoginCheck
 * 
 */

@WebServlet("/LoginCheck")

public class LoginCheck extends HttpServlet {

	private static final long serialVersionUID = 1L;

	/**
	 * 
	 * @see HttpServlet#HttpServlet()
	 */

	private static final String APPLICATION_NAME = "Google Calendar API Java Quickstart";
	private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
	@SuppressWarnings("unused")
	private static final String TOKENS_DIRECTORY_PATH = "tokens";

	/**
	 * 
	 * Global instance of the scopes required by this quickstart. If modifying these
	 * scopes, delete your previously saved tokens/ folder.
	 */

	private static final List<String> SCOPES = Collections.singletonList(CalendarScopes.CALENDAR_READONLY);
	private static final String CREDENTIALS_FILE_PATH = "credentials.json";
	String pic;
	InputStream in;
	GoogleClientSecrets clientSecrets;
	final NetHttpTransport HTTP_TRANSPORT;

	public LoginCheck() throws IOException, GeneralSecurityException {
		super();
		System.out.println("In Constructor");
		if (CREDENTIALS_FILE_PATH == null) {
			System.out.println("filename is null");
		}
		in = LoginCheck.class.getResourceAsStream(CREDENTIALS_FILE_PATH);
		if (in == null) {
			System.out.println("stream is null");
		}
		clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));
		HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
	}

	

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	// global variables so that all parts of service can access them when needed
	TokenResponse aToken;
	String userName;
	Calendar service;
	Credential credential;
	HttpSession session;
	Events events;
	String emailAddress;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String accessToken = request.getParameter("accessToken");
		String makeTable = request.getParameter("makeTable");
		String userInfo = request.getParameter("userInfo");
		String EventTitle = request.getParameter("EventTitle");
		String follow = request.getParameter("Follow");
		String search = request.getParameter("Search");
		
		System.out.println("calling accessTOken" + accessToken);

		
		
			// accessToken is influenced by the google api quickstart, but modified to fit a
			// web application, as well as my intended fields
			// used Jamie's tutorial on piazza to help me with this
			if (accessToken != null) {
				String googleID = request.getParameter("googleID");
				pic = request.getParameter("imgURL");
				userName = request.getParameter("fullName");
				String email = request.getParameter("email");

				// Build flow and trigger user authorization request.
				GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(HTTP_TRANSPORT, JSON_FACTORY,
						clientSecrets, SCOPES).setAccessType("online")
								.setDataStoreFactory(MemoryDataStoreFactory.getDefaultInstance()).build();
				aToken = new TokenResponse();
				aToken.setAccessToken(request.getParameter("accessToken"));

				credential = flow.createAndStoreCredential(aToken, googleID);
				service = new Calendar.Builder(HTTP_TRANSPORT, JSON_FACTORY, credential)
						.setApplicationName(APPLICATION_NAME).build();

				// store in sessions so that I can access outside of the scope
				session = request.getSession(true);
				session.setAttribute("Calendar", service);
				session.setAttribute("googleID", googleID);
				session.setAttribute("accessToken", aToken);
				session.setAttribute("imageURL", pic);
				session.setAttribute("UserName", userName);
				session.setAttribute("Email", email);

				String name = userName;
				String image = pic;
				emailAddress = email;
			
				System.out.println("calling add user");
				JDBCDriver.addUser(emailAddress, image, name);
				DateTime now = new DateTime(System.currentTimeMillis());

				com.google.api.services.calendar.model.Events events = service.events().list("primary")
						.setMaxResults(15).setTimeMin(now).setOrderBy("startTime").setSingleEvents(true).execute();

				List<Event> items = events.getItems();
				
				System.out.println("calling add events");
				JDBCDriver.addEvents(emailAddress, items);
				
				RequestDispatcher dd=request.getRequestDispatcher("Profile.jsp");
				dd.forward(request, response);			}
			// this function outputs my users picture and name to the webpage that I am on,
			// this occurs on both Profile.jsp and Homepage.jsp, used information that we
			// learned in class to form these statements
			if (userInfo == "true") {
				response.setContentType("text/html");
				PrintWriter out = null;
				out = response.getWriter();
				if (out!=null)
				{
					//out = response.getWriter();
					out.println(" <img src=" + session.getAttribute("imageURL") + ">");
					out.println("<h1>" + session.getAttribute("UserName") + "</h1>");

				}
					
				
			}
			// The following function was taken from part of the google api for building a
			// calendar and was modified to display the month and time in the format i
			// desired as well as output the events in a table
			// errors sometimes occur on line 141
			if (makeTable == "true") {
				System.out.println("In Make Table");
				response.setContentType("text/html");
				PrintWriter out = response.getWriter();
				DateTime now = new DateTime(System.currentTimeMillis());

				com.google.api.services.calendar.model.Events events = service.events().list("primary")
						.setMaxResults(10).setTimeMin(now).setOrderBy("startTime").setSingleEvents(true).execute();

				List<Event> items = null;
				if (events.getItems() != null)
				{
					items = events.getItems();;
				}
				
			
				
				
				// only loop through if items exist
				if (items == null) {
				} else {
					JDBCDriver.addEvents(emailAddress, items);
					out.println("<tr>" + "<th>" + "Date" + "</th>" + "<th>" + "Time" + "</th>" + "<th>"
							+ "Event Summary" + "</th>" + "</tr>");
					for (int i = 0; i < items.size(); i++) {
						Event event = items.get(i);
						out.println("<tr>");
						DateTime start = event.getStart().getDateTime();
						if (start == null) {
							start = event.getStart().getDate();
						}

						String dtStr = start.toString();

						String year = dtStr.substring(0, 4);
						String month = dtStr.substring(5, 7);
						if (month.equals("01")) {
							month = "January";
						} else if (month.equals("02")) {
							month = "February";
						} else if (month.equals("03")) {
							month = "March";
						} else if (month.equals("04")) {
							month = "April";
						} else if (month.equals("05")) {
							month = "May";
						} else if (month.equals("06")) {
							month = "June";
						} else if (month.equals("07")) {
							month = "July";
						} else if (month.equals("08")) {
							month = "August";
						} else if (month.equals("09")) {
							month = "September";
						} else if (month.equals("10")) {
							month = "October";
						} else if (month.equals("11")) {
							month = "November";
						} else if (month.equals("12")) {
							month = "December";
						}
						String day = dtStr.substring(8, 10);
						String startTime = dtStr.substring(11, 16);
						String aP = startTime.substring(0, 2);
						String half = "";
						if (aP.equals("12") || aP.equals("13") || aP.equals("14") || aP.equals("15") || aP.equals("16")
								|| aP.equals("17") || aP.equals("18") || aP.equals("19") || aP.equals("20")
								|| aP.equals("21") || aP.equals("22") || aP.equals("23")) {
							half = "PM";
							if (aP.equals("13")) {
								aP = "01";
								startTime = aP + startTime.substring(2, startTime.length());
							}
							if (aP.equals("14")) {
								aP = "02";
								startTime = aP + startTime.substring(2, startTime.length());

							}
							if (aP.equals("15")) {
								aP = "03";
								startTime = aP + startTime.substring(2, startTime.length());

							}
							if (aP.equals("16")) {
								aP = "04";
								startTime = aP + startTime.substring(2, startTime.length());

							}
							if (aP.equals("17")) {
								aP = "05";
								startTime = aP + startTime.substring(2, startTime.length());

							}
							if (aP.equals("18")) {
								aP = "06";
								startTime = aP + startTime.substring(2, startTime.length());

							}
							if (aP.equals("19")) {
								aP = "07";
								startTime = aP + startTime.substring(2, startTime.length());

							}
							if (aP.equals("20")) {
								aP = "08";
								startTime = aP + startTime.substring(2, startTime.length());

							}
							if (aP.equals("21")) {
								aP = "09";
								startTime = aP + startTime.substring(2, startTime.length());

							}
							if (aP.equals("22")) {
								aP = "10";
								startTime = aP + startTime.substring(2, startTime.length());

							}
							if (aP.equals("23")) {
								aP = "11";
								startTime = aP + startTime.substring(2, startTime.length());

							}

							half = "PM";

						} else {
							half = "AM";
						}
						if (aP.equals("00")) {
							startTime = "12" + startTime.substring(2, startTime.length());
						}
						String date = month + " " + day + ", " + year;
						String time = startTime + half + " ";
						String summary = event.getSummary();
						
						out.println("<td>" + date + "</td>");
						out.println("<td>" + time + "</td>");
						out.println("<td>" + event.getSummary() + "</td>");
						out.println("</tr>");
						
					}
				}
				out.println("</table>");
				out.println("</div>");
				out.flush();
				out.close();
				makeTable = null;

			}

			// add a new event to the user calendar--> error pop up if desired field not
			// there, and success pop up and redirect to profile if event create was
			// successful
			if (EventTitle != null) {
				PrintWriter out = response.getWriter();

				String eventTitle = request.getParameter("EventTitle");
				String startDate = request.getParameter("StartDate");
				String endDate = request.getParameter("EndDate");
				String startTime = request.getParameter("StartTime");
				String endTime = request.getParameter("EndTime");

				String id = (String) session.getAttribute("googleID");

				Event event = new Event().setSummary(eventTitle);

				String startDT = startDate + "T" + startTime + ":00-00:00";
				String endDT = endDate + "T" + endTime + ":00-00:00";

				DateTime SDT = new DateTime(startDT);
				EventDateTime start = new EventDateTime().setDateTime(SDT).setTimeZone("America/Los_Angeles");
				event.setStart(start);

				DateTime EDT = new DateTime(endDT);
				EventDateTime end = new EventDateTime().setDateTime(EDT).setTimeZone("America/Los_Angeles");
				event.setEnd(end);

				String calendarID = "primary";
				event = service.events().insert(calendarID, event).execute();

				out.println("<script> alert(\"Event Created!\") </script>");
				out.println("<script> window.location.replace(\"Profile.jsp\")</script>");

			}

			else if (search != null)
			{
				ArrayList<ArrayList<String> > result = JDBCDriver.searchResults(search);
				
				PrintWriter out = response.getWriter();
				
				for (int i = 0; i < result.size(); i++)
				{
					out.println(" <img src=" + result.get(i).get(1) + ">");
					out.println("<h1>" + result.get(i).get(0) + "</h1>");
				}
				response.sendRedirect("SearchResults.jsp");
			}
			
			else if (follow != null) {
				String emailAddress = request.getParameter("email");
				String friendAddress = request.getParameter("friend");

				
			}

	}

}
