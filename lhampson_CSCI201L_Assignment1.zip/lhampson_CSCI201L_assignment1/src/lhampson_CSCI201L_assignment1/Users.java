package lhampson_CSCI201L_assignment1;


import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Users {

	@SerializedName("Name")
	@Expose
	private Name name;
	@SerializedName("Events")
	@Expose
	private List<Events> events = null;

	//Users contain a Name variable(that contains a first name and a last name), as well as a list of Events that specific user has in their calender
	public Name getName() {
		return name;
	}

	public void setName(Name name) {
		this.name = name;
	}

	public List<Events> getEvents() {
		return events;
	}

	public void setEvents(List<Events> events) {
		this.events = events;
	}
	
}
