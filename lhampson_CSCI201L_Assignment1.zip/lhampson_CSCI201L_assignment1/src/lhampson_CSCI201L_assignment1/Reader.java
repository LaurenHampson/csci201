package lhampson_CSCI201L_assignment1;


import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Reader {

	@SerializedName("Users")
	@Expose
	private List<Users> users = null;

	//each JSON file input should have a variable type Users, its objects will be stored in a List of Users
	public List<Users> getUsers() {
		return users;
	}

	public void setUsers(List<Users> users) {
		this.users = users;
	}
}