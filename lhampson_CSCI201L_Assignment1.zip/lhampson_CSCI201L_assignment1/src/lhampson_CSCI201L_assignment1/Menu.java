package lhampson_CSCI201L_assignment1;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class Menu {

	private int input;

	public Menu(boolean valid) {

		input = 0;

	}

	// Event sorter method --> Takes the list of events for each user and sorts them
	// in chronological order, first by year, then by month, then by day

	public List<Events> eventSorter(List<Events> e) {
		if (e.size() == 1 || e.size() == 0) {
			return e;
		}
		List<Integer> yearTemp = new ArrayList<Integer>();
		for (int i = 0; i < e.size(); i++) {
			yearTemp.add(e.get(i).getDate().getYear());
		}

		Events[] retList = new Events[yearTemp.size()];
		Collections.sort(yearTemp);
		for (int a = 0; a < yearTemp.size(); a++) {
			if (e.get(a).getDate().getYear() == yearTemp.get(a)) {
				retList[a] = (e.get(a));
			} else {
				int b = 0;
				while (e.get(b).getDate().getYear() != yearTemp.get(a)) {
					b++;
				}
				retList[a] = (e.get(b));
			}
		}
		Events temp = null;
		for (int i = 0; i < retList.length - 1; i++) {
			for (int j = i + 1; j < retList.length; j++) {
				if (retList[i].getDate().getDay() > retList[j].getDate().getDay()) {
					temp = retList[j];
					retList[j] = retList[i];
					retList[i] = temp;
				}
			}
		}

		for (int i = 0; i < retList.length - 1; i++) {
			for (int j = i + 1; j < retList.length; j++) {
				if (monther(retList[i].getDate().getMonth()) == monther(retList[j].getDate().getMonth())) {
					if (retList[i].getDate().getDay() > retList[j].getDate().getDay()) {
						temp = retList[j];
						retList[j] = retList[i];
						retList[i] = temp;
					}
				} else if (monther(retList[i].getDate().getMonth()) > monther(retList[j].getDate().getMonth())) {
					temp = retList[j];
					retList[j] = retList[i];
					retList[i] = temp;
				}
			}
		}

		List<Events> eList = new ArrayList<Events>();
		for (int i = 0; i < retList.length; i++) {
			eList.add(retList[i]);
		}

		return eList;

	}

	// monther method--> returns the equivalent integer for each month string so
	// that sorting is easier
	public static int monther(String month) {
		if (month.equals("January")) {
			return 1;
		} else if (month.equals("February")) {
			return 2;
		} else if (month.equals("March")) {
			return 3;
		} else if (month.equals("April")) {
			return 4;

		} else if (month.equals("May")) {
			return 5;

		} else if (month.equals("June")) {
			return 6;
		} else if (month.equals("July")) {
			return 7;

		} else if (month.equals("August")) {
			return 8;

		} else if (month.equals("September")) {
			return 9;
		} else if (month.equals("October")) {
			return 10;

		} else if (month.equals("November")) {
			return 11;

		} else {
			return 12;

		}
	}

	// Show menu allows for the user to edit and display the json file as long as
	// they want, will save directly to the file that they open from
	// overriding the original file
	public boolean ShowMenu(boolean valid, Reader in2, List<Users> u, String inputFilename) {

		int sorter = 0; // global sorter variable to make sure that once the user has sorted their Users
						// in a specific way, the program will remember to always sort it that way
		boolean edited = false; // global boolean variable that will make sure the user is prompted to save
								// their file when they exit if changes have been made throughout the program
		while (!valid) {

			System.out.println("1) Display User's Calendar");

			System.out.println("2) Add User ");
			System.out.println("3) Remove User ");
			System.out.println("4) Add Event ");
			System.out.println("5) Delete Event ");
			System.out.println("6) Sort Users ");
			System.out.println("7) Write File ");
			System.out.println("8) Exit ");

			System.out.print("What would you like to do? ");

			Scanner in = new Scanner(System.in);

			try {
				input = in.nextInt();
				if (input == 1) {
					for (int i = 0; i < u.size(); i++) {
						Name person = u.get(i).getName();
						System.out.print(i + 1);
						System.out.print(") ");
						System.out.println(person.getLname() + ", " + person.getFname());
						List<Events> e = u.get(i).getEvents();
						if (e != null && e.size() > 1) {
							e = eventSorter(e);
							u.get(i).setEvents(e);
							// after sorting the events in chronological order, update the events list for
							// that specific user, so that you are accessing the correct variable if you add
							// or remove an event
						}

						// make sure that the user actually has events so that there isnt an out of
						// bounds access error
						if (e != null) {
							for (int a = 0; a < e.size(); a++)

							{
								char eLetter = (char) (a + 97);
								System.out.print("      " + eLetter + ". " + e.get(a).getTitle() + ", "
										+ e.get(a).getTime() + ", ");

								Date d = e.get(a).getDate();

								System.out.print(d.getMonth() + " " + d.getDay() + ", " + d.getYear());
								System.out.println("");

							}
						}
						// if user has previously chosen to sort their users in a specific way, ensure
						// that they are sorted that same way every time a new one is added
						if (sorter == 1) {
							u = ascending(u);
							in2.setUsers(u);
							edited = true;
						} else if (sorter == 2) {
							u = descending(u);
							in2.setUsers(u);
							edited = true;
						}

					}

				}
				// Add a new user
				// Various error checks:
				// 		Ensure that the name entered has a first name or last name
				// 			if not ask again
				// 		Ensure that the name entered isnt already in the users list
				// 			ignore case
				// 			if it is, ask again
				else if (input == 2) {
					boolean nameFound = false;
					String Fname = "";
					String Lname = "";

					System.out.println("What is the user's name? ");
					String name = in.next();
					name += in.nextLine();

					while (!nameFound) {

						String[] result = name.split(" ");

						if (result.length > 1) {
							Fname = result[0];
							int i = 1;
							while (i < result.length) {
								Lname += result[i];
								if (i + 1 != result.length) {
									Lname += " ";
								}
								i++;
							}

							boolean sameName = false;

							for (int a = 0; a < u.size(); a++) {
								if ((u.get(a).getName().getFname().toLowerCase()).equals(Fname.toLowerCase())
										&& (u.get(a).getName().getLname().toLowerCase()).equals(Lname.toLowerCase())) {
									System.out.println("A user with this name already exists, please enter another: ");
									name = in.next();
									name += in.nextLine();
									sameName = true;
									Lname = "";
									Fname = "";
									break;
								}

							}

							if (sameName == false) {
								nameFound = true;
							}

							if (nameFound == true) {
								List<Events> e = null;
								Name n = new Name(Fname, Lname, e);
								Users x = new Users();
								x.setName(n);
								x.setEvents(e);
								u.add(x);
								// make sure that you are always sorting the users in the correct way that the
								// user previously inputted
								if (sorter == 1) {
									u = ascending(u);
									in2.setUsers(u);
									edited = true;
								} else if (sorter == 2) {
									u = descending(u);
									in2.setUsers(u);
									edited = true;
								}
							}

						}

						else if (result.length <= 1) {
							System.out.println("Please enter a full name (first and last)");
							System.out.println();
							System.out.println("What is the user's name? ");
							name = in.next();
							name += in.nextLine();

						}

					}
					edited = true;

				}
				// Remove a user--> ensure that the user is entering an integer corresponding to
				// their specified user, ensure that that integer is in range, and ensure that
				// the users list is not null
				else if (input == 3) {
					if (u.size() == 0) {
						System.out.println("JSON file contains no users.");
					} else {
						for (int i = 0; i < u.size(); i++) {
							Name person = u.get(i).getName();
							System.out.print(i + 1);
							System.out.print(") ");
							System.out.println(person.getLname() + ", " + person.getFname());
						}
						int remover = 0;
						boolean trier = false;
						while (!trier) {
							System.out.println("Which user would you like to remove?");
							remover = in.nextInt();
							if (u.size() < remover || remover == 0) {
								System.out.println("Invalid user, please choose another: ");

								for (int i = 0; i < u.size(); i++) {
									Name person = u.get(i).getName();
									System.out.print(i + 1);
									System.out.print(") ");
									System.out.println(person.getLname() + ", " + person.getFname());
								}
							} else {
								trier = true;
							}
						}

						u.remove(u.get(remover - 1));
						edited = true;
					}
				}
				// add an event for a specified user--> ensure that they have entered an integer
				// for their specified user, ensure that that integer is in range, ensure that
				// the users list is not null, ensure that the user is entering the correct
				// variable type and in range for title, time, month, day, and year
				else if (input == 4) {
					for (int i = 0; i < u.size(); i++) {
						Name person = u.get(i).getName();
						System.out.print(i + 1);
						System.out.print(") ");
						System.out.println(person.getLname() + ", " + person.getFname());
					}

					boolean validUser = false;
					int adder = 0;
					while (validUser == false) {
						System.out.println("For which user would you like to add an event?");

						adder = in.nextInt();
						if (adder > u.size() || adder == 0) {
							System.out.println("Invalid user, please choose another");
							in.nextLine();
						} else {
							validUser = true;

						}
					}

					System.out.println("What is the title of your event?");
					String title = in.next();
					title += in.nextLine();

					boolean isInt = false;
					int month = 0;

					do {
						System.out.println("What month is your event? (as an integer)");

						if (in.hasNextInt()) {
							month = in.nextInt();
							isInt = true;
						} else {
							System.out.println("Please enter the month as an integer");
							in.next();
							isInt = false;
						}
					} while (isInt == false || month < 1 || month > 12);

					int day = 0;
					isInt = false;

					do {
						System.out.println("What day is your event? (as an integer)");

						if (in.hasNextInt()) {
							day = in.nextInt();
							isInt = true;
						} else {
							System.out.println("Please enter the day as an integer");
							in.next();
							isInt = false;
						}
					} while (isInt == false || day < 1 || day > 31);

					int year = 0;
					isInt = false;

					do {
						System.out.println("What year is your event? (as an integer)");

						if (in.hasNextInt()) {
							year = in.nextInt();
							isInt = true;
						} else {
							System.out.println("Please enter the year as an integer");
							in.next();
							isInt = false;
						}
					} while (isInt == false);

					System.out.println("What time is your event?");
					String time = in.next();
					time += in.nextLine();

					String strMonth = toMonth(month);
					Date d = new Date(strMonth, day, year);

					Events e = new Events(title, time, d);

					if (u.get(adder - 1).getEvents() == null) {
						List<Events> eList = new ArrayList<Events>();
						eList.add(e);
						u.get(adder - 1).setEvents(eList);
					} else {
						List<Events> eList = u.get(adder - 1).getEvents();
						eList.add(e);
						if (eList != null && eList.size() > 1) {
							eList = eventSorter(eList);
						}
						u.get(adder - 1).setEvents(eList);

					}
					edited = true;

				}
				// removing an event --> ensure that the user enters an integer for which user
				// they want to remove an event from, ensure that it is a valid user,ensure that
				// that user has events to remove from, ensure that the event chosen to remove
				// is in range, remove event
				else if (input == 5) {
					for (int i = 0; i < u.size(); i++) {
						Name person = u.get(i).getName();
						System.out.print(i + 1);
						System.out.print(") ");
						System.out.println(person.getLname() + ", " + person.getFname());

					}

					boolean validUser = false;
					int peep = 0;
					while (validUser == false) {
						System.out.println("For which user would you like to remove an event?");

						peep = in.nextInt();
						if (peep > u.size() || peep == 0) {
							System.out.println("Invalid user, please choose another");
							in.nextLine();
						} else {
							validUser = true;

						}
					}

					List<Events> e = u.get(peep - 1).getEvents();
					if (e == null) {
						System.out.println("This user has no events to delete.");
					} else if (e != null) {
						if (e != null && e.size() > 1) {
							e = eventSorter(e);
							u.get(peep - 1).setEvents(e);

						}
						for (int a = 0; a < e.size(); a++)

						{

							System.out.print(a + 1 + ")" + e.get(a).getTitle() + ", " + e.get(a).getTime() + ", ");

							Date d = e.get(a).getDate();

							System.out.print(d.getMonth() + " " + d.getDay() + " ," + d.getYear());
							System.out.println("");

						}

						System.out.println("Which event would you like to remove?");
						int remover = in.nextInt();
						if (u.get(peep - 1).getEvents().size() < remover || remover < 1) {
							System.out.println("Not a valid event");
						}
						// add error checkers here to make sure that they are removing a valid user
						else {
							u.get(peep - 1).getEvents().remove(remover - 1);
						}

						edited = true;
					}
				}
				// sort the users based on last name(and if last name is the same sort by first
				// name) per user choice (either ascending or descending)
				// ensure that the users are updated in the json file so that access is where
				// you want it to be in other operations
				else if (input == 6) {
					System.out.println("1) Ascending (A-Z)");
					System.out.println("2) Descending (Z-A)");
					System.out.println();
					System.out.println("How would you like to sort? ");
					sorter = in.nextInt();

					if (sorter == 1) {
						u = ascending(u);
						in2.setUsers(u);
						edited = true;
					} else if (sorter == 2) {
						u = descending(u);
						in2.setUsers(u);
						edited = true;
					}

				}
				// ensure that correctly sorted, then save file if changes have been made(edited
				// == true)
				else if (input == 7) {

					if (sorter == 1) {
						u = ascending(u);
						in2.setUsers(u);
						edited = true;
					} else if (sorter == 2) {
						u = descending(u);
						in2.setUsers(u);
						edited = true;
					}
					fileSave(inputFilename, in2, u);
					edited = false;
					System.out.println("File has been saved.");

				}

				// exit the program
				// if changes have been made prompt the user to save it
				// if user does not want to save, dont save and exit the program
				// if user does want to save, save and then exit the program (make sure
				// everything is sorted the way it is supposed to be before exiting)
				else if (input == 8) {
					if (edited == true) {
						System.out.println("Changes have been made since the file was last saved");
						System.out.println("    1) Yes");
						System.out.println("    2) No");
						System.out.println("Would you like to save the file before exiting?");
						int saver = in.nextInt();

						if (saver == 2) {
							System.out.println("File was not saved.");
							System.out.println();
						}

						else {
							if (sorter == 1) {
								u = ascending(u);
								in2.setUsers(u);
								edited = true;
							} else if (sorter == 2) {
								u = descending(u);
								in2.setUsers(u);
								edited = true;
							}
							fileSave(inputFilename, in2, u);
							System.out.println("File has been saved.");
							System.out.println();
							edited = false;
						}

						System.out.println("Thank you for using my program!");
						valid = true;
						in.close();
					} else {
						System.out.println("Thank you for using my program!");
						valid = true;
						in.close();

					}

				}
				// ensure that the user is entering a valid menu index and then check if input
				// is an integer
				else {

					System.out.println("That is not a valid option. ");

				}

			} catch (InputMismatchException ime) {

				System.out.println("Please put your input as a number");

			}

		}

		return true;

	}

	// method to write the changed file to the inputted filename overwriting what
	// was originally there
	private void fileSave(String inputFilename, Reader in2, List<Users> u) {
		Gson gson = new GsonBuilder().serializeNulls().disableHtmlEscaping().setPrettyPrinting().create();

		// convert the Java object to json
		String jsonString = gson.toJson(in2);
		// Write JSON String to file
		FileWriter fileWriter = null;
		try {
			fileWriter = new FileWriter(inputFilename);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			fileWriter.write(jsonString);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			fileWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	// method to change the input from add event to its proper string variable type
	private String toMonth(int month) {
		if (month == 1) {
			return "January";
		} else if (month == 2) {
			return "February";
		} else if (month == 3) {
			return "March";
		} else if (month == 4) {
			return "April";

		} else if (month == 5) {
			return "May";

		} else if (month == 6) {
			return "June";
		} else if (month == 7) {
			return "July";

		} else if (month == 8) {
			return "August";

		} else if (month == 9) {
			return "September";
		} else if (month == 10) {
			return "October";

		} else if (month == 11) {
			return "November";

		} else {
			return "December";

		}

	}

	// method to sort users from A-Z
	public List<Users> ascending(List<Users> u) {
		List<String> fnames = new ArrayList<String>();
		for (int i = 0; i < u.size(); i++) {
			fnames.add(u.get(i).getName().getFname());
		}
		Collections.sort(fnames, String.CASE_INSENSITIVE_ORDER);
		List<Users> temp = new ArrayList<Users>();
		for (int a = 0; a < fnames.size(); a++) {
			if (u.get(a).getName().getFname() == fnames.get(a)) {
				temp.add(u.get(a));
			} else {
				int b = 0;
				while (u.get(b).getName().getFname() != fnames.get(a)) {
					b++;
				}
				temp.add(u.get(b));
			}
		}

		List<String> names = new ArrayList<String>();
		for (int i = 0; i < temp.size(); i++) {
			names.add(temp.get(i).getName().getLname());
		}
		Collections.sort(names, String.CASE_INSENSITIVE_ORDER);
		List<Users> retList = new ArrayList<Users>();
		for (int a = 0; a < names.size(); a++) {
			if (temp.get(a).getName().getLname() == names.get(a)) {
				retList.add(temp.get(a));
			} else {
				int b = 0;
				while (temp.get(b).getName().getLname() != names.get(a)) {
					b++;
				}
				retList.add(temp.get(b));
			}
		}

		return retList;
	}

	// method to sort users from Z-A
	public List<Users> descending(List<Users> u) {

		List<Users> names = ascending(u);
		List<Users> temp = new ArrayList<Users>();

		for (int i = names.size() - 1; i >= 0; i--) {
			temp.add(names.get(i));
		}

		return temp;
	}

}
