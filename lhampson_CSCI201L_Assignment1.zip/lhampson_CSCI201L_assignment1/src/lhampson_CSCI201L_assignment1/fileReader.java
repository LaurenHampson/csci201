package lhampson_CSCI201L_assignment1;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;

public class fileReader {

	public static void main(String[] args) {

		boolean valid = false;
		// boolean variable to allow for input until valid json file is found

		Scanner scan = new Scanner(System.in);

		while (!valid) {
			System.out.print("Enter the JSON file name: ");
			String inputFilename = scan.nextLine();

			Gson gson = new Gson();
			try {
				Reader in = gson.fromJson(new FileReader(inputFilename), Reader.class);
				// Reader parses the information from the JSON file into its respective objects

				Menu menu = new Menu(valid);
				// menu object allows for operations of the input file, and ShowMenu displays
				// the menu for user input and changes
				menu.ShowMenu(valid, in, in.getUsers(), inputFilename);

				valid = true;
				scan.close();
				// when the program is complete exit the while loop
			}
			//various catch statements for the different errors that the user inputted file can have 
			catch (JsonSyntaxException jse) {

				System.out.println("That file is not a well-formed JSON file. ");

			} catch (FileNotFoundException fnfe) {
				System.out.println("fnfe: " + fnfe.getMessage());
			}

			catch (@SuppressWarnings("hiding") IOException ioe) {
				System.out.println("ioe: " + ioe.getMessage());
			} catch (JsonIOException jioe) {
				System.out.println("Invalid read of file");
			}

		}
	}

}
