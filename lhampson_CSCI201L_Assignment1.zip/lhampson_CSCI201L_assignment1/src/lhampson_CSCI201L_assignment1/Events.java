package lhampson_CSCI201L_assignment1;



import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Events {

	@SerializedName("Title")
	@Expose
	private String title;
	@SerializedName("Time")
	@Expose
	private String time;
	@SerializedName("Date")
	@Expose
	private Date date;

	public Events() {

	}

	//Custom Constructor for creating new Events in Menu.java
	//Not used when originally parsing in the data
	public Events(String title, String time, Date date) {
		this.title = title;
		this.time = time;
		this.date = date;
	}
	
	//Events contain three parts, a title, a time, and a Date
	//title and time are read directly into their strings in this class
	//Date is its own object that contains a Month Day and Year

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}
	

	

}