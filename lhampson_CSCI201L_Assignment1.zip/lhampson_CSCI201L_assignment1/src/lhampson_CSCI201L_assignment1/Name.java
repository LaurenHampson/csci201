package lhampson_CSCI201L_assignment1;

import java.util.List;

public class Name {

	private List<Events> events;
	private String Fname;
	private String Lname;
	
	//instantiate the first name, last name, and events list of each specific User
	
	public Name()
	{
		
	}
	public Name(String Fname, String Lname, List<Events> events) {
		
		this.Fname = Fname;
		this.Lname = Lname;
		this.events = events;
	}
	
	public String getName()
	{
		return Fname + " " + Lname;
	}
	public void setName(String Fname, String Lname)
	{
		this.Fname = Fname;
		this.Lname = Lname;
	}
	public String getFname()
	{
		return Fname;
	}
	
	public String getLname()
	{
		return Lname;
	}
	
	public void setFname(String Fname)
	{
		this.Fname = Fname;
	}
	
	public void setLname(String Lname)
	{
		this.Lname = Lname;
	}
	public List<Events> getEvents()
	{
		return events;
	}
	
	public void setEvents(List<Events> events)
	{
		this.events = events;
	}
	

}
