package lhampson_CSCI201L_assignment1;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Date {

	@SerializedName("Month")
	@Expose
	private String month;
	@SerializedName("Day")
	@Expose
	private Integer day;
	@SerializedName("Year")
	@Expose
	private Integer year;
	
	//instantiate the month day and year for each event
	
	public Date()
	{
		
	}
	
	public Date(String month, int day, int year)
	{
		this.month = month;
		this.day = day;
		this.year = year;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public Integer getDay() {
		return day;
	}

	public void setDay(Integer day) {
		this.day = day;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

}