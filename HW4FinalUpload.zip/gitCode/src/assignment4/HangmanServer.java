/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment4;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import java.util.Vector;

/**
 *
 * @author master
 */
public class HangmanServer {
	public static Vector<String> configFile1 = new Vector<String>();
	public static Vector<String> configFile = new Vector<String>();
	public static Vector<String> configWords = new Vector<String>();
	public static String ServerHostname = null;
	public static String ServerPort = null;
	public static String DBConnection = null;
	public static String DBUsername = null;
	public static String DBPassword = null;
	public static String SecretWordFile = null;
	public static ServerSocket s;
	// private Vector<ServerThread> serverThreads;
	public static WordGenerator wordGenerator = null;

	

	public static void main(String[] args) throws IOException {

		System.out.println("Welcome to Hangman!");
		// prompt the user to enter the configuration file
		System.out.println("What is the name of the configuration file? ");
		Scanner scan = new Scanner(System.in);
		String configFilename = scan.nextLine();
		FileReader fr = null;
		BufferedReader br = null;

		// open the config file and read the parameters !!!!! to do --> use the
		// "properties" class
		try {
			fr = new FileReader(configFilename);
			br = new BufferedReader(fr);
			String line = br.readLine();
			while (line != null) {
				configFile.add(line);
				line = br.readLine();
			}
			for (int i = 0; i < configFile.size(); i++) {
				String ss = configFile.get(i);
				String[] parts = ss.split("=");
				configFile1.add(parts[0]); // before the equals
				configFile1.add(parts[1]); // after the equals
			}
		} catch (FileNotFoundException fnfe) {
			System.out.println(fnfe.getMessage());
		} catch (IOException ioe) {
			System.out.println(ioe.getMessage());
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException ioe) {
					System.out.println(ioe.getMessage());
				}
			}
			if (fr != null) {
				try {
					fr.close();
				} catch (IOException ioe) {
					System.out.println(ioe.getMessage());
				}
			}
		}
		// look for what is missing, ask the user to enter a configuration file with
		// that format
		for (int i = 0; i < configFile1.size(); i++) {
			if (configFile1.get(i).equals("ServerHostname")) {
				ServerHostname = configFile1.get(i + 1);
			}
			if (configFile1.get(i).equals("ServerPort")) {
				ServerPort = configFile1.get(i + 1);
			}
			if (configFile1.get(i).equals("DBConnection")) {
				DBConnection = configFile1.get(i + 1);
			}
			if (configFile1.get(i).equals("DBUsername")) {
				DBUsername = configFile1.get(i + 1);
			}
			if (configFile1.get(i).equals("DBPassword")) {
				DBPassword = configFile1.get(i + 1);
			}
			if (configFile1.get(i).equals("SecretWordFile")) {
				SecretWordFile = configFile1.get(i + 1);
			}
		}

		boolean missing = false;
		if (ServerHostname == null || ServerPort == null || DBConnection == null || DBUsername == null
				|| DBPassword == null || SecretWordFile == null) {

			if (ServerHostname == null) {
				System.out.println("ServerHostname is a required parameter in the configuration file");
				missing = true;
			}
			if (ServerPort == null) {
				System.out.println("ServerPort is a required parameter in the configuration file");
				missing = true;

			}
			if (DBConnection == null) {
				System.out.println("DBConnection is a required parameter in the configuration file");
				missing = true;
			}
			if (DBUsername == null) {
				System.out.println("DBUsername is a required parameter in the configuration file");
				missing = true;

			}
			if (DBPassword == null) {
				System.out.println("DBPassword is a required parameter in the configuration file");
				missing = true;

			}
			if (SecretWordFile == null) {
				System.out.println("SecretWordFile is a required parameter in the configuration file");
				missing = true;
			}
		}

		// add how to get the correct configuration file here

		// if anything is missing terminate the program
		if (missing == true) {
			scan.close();
			// return;
			System.exit(0); // ask about this
		}

		// if the configuration file is correct
		// output all of the parameters

		System.out.println("Server Hostname - " + ServerHostname);
		System.out.println("Server Port - " + ServerPort);
		System.out.println("Database Connection String - " + DBConnection);
		System.out.println("Database Username - " + DBUsername);
		System.out.println("Database Password - " + DBPassword);
		System.out.println("Secret Word File - " + SecretWordFile);

		String[] dc = DBConnection.split(" ");
		DBConnection = dc[0];
		String[] du = DBUsername.split(" ");
		DBUsername = du[0];
		String[] dp = DBPassword.split(" ");
		DBPassword = dp[0];
		JDBCDriver.initialConnect(DBConnection, DBUsername, DBPassword);

		// JDBC code to add the words to the database
		// select a random word each time
		fr = null;
		br = null;

		try {
			fr = new FileReader(SecretWordFile);
			br = new BufferedReader(fr);
			String line = br.readLine();
			while (line != null) {
				configWords.add(line);
				line = br.readLine();
			}

		} catch (FileNotFoundException fnfe) {
			System.out.println(fnfe.getMessage());
		} catch (IOException ioe) {
			System.out.println(ioe.getMessage());
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException ioe) {
					System.out.println(ioe.getMessage());
				}
			}
			if (fr != null) {
				try {
					fr.close();
				} catch (IOException ioe) {
					System.out.println(ioe.getMessage());
				}
			}
		}

		if (configWords.isEmpty()) {
			// Output that the configuration file is empty and unable to get a word
		}
		String[] pa = ServerPort.split(" ");
		ServerPort = pa[0];
		int port = Integer.parseInt(ServerPort);

		s = new ServerSocket(port);
		System.out.println("Successfully started the Hangman server on port " + port);
		WordGenerator wg = new WordGenerator(configWords);
		String gameWord = wg.getRandomWord();
		new HangmanClub(s, DBConnection, DBUsername, DBPassword, gameWord).openClub();// Opening BlackJack Club
		s.close();// Closing server socket
		while (true) {
			Socket socket = s.accept();
			InputStream is = socket.getInputStream();
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader bd = new BufferedReader(isr);
			String number = bd.readLine();
			System.out.println(number);
		}

	}

}
