package assignment4;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

public class HangmanPlayer{
    private Socket socket;//player socket
    private BufferedReader is;//input from socket
    private PrintWriter os;//output to socket
    private String name;
    private int chips;
    private int betChips;
    private int guesses;
    private boolean isBusted;//set to true if player is busted (point > 21)
    private ArrayList<String> cards;
    private ArrayList<String> cardsMsg;
    public HangmanPlayer(String _name, Socket _socket, PrintWriter _os, BufferedReader _is){
        this.name=_name;
        this.socket=_socket;
        this.is=_is;
        this.os=_os;
     
        this.isBusted=false;
        this.guesses = 7;
    }
    
    //getter for player name
    public String getName(){
        return this.name;
    }
  
 
    public int getGuesses()
    {
    	return this.guesses;
    }
    public void addWin()
    {
    	
    }
    public void addLoss()
    {
    	
    }
    public void setGuesses()
    {
    	this.guesses = this.guesses-1;
    	if(this.guesses == 0)
    	{
    		gameLost();
    	}
    }
    
    public void gameLost()
    {}
    public void gameWon()
    {}
   
    public void revealWord()
    {
    	
    }
    public void gameOver()
    {

    }
    
    
   
    
    public void sendMessage(String _message){
    	
        this.os.println(_message);//sending message to client
    }
    
    public void sendStatus(String _message){
        this.os.println(_message);//sending status to client
    }
    
    public PrintWriter getPrintWriter(){
        return this.os;
    }
 
    
    //os => Input socket
    public BufferedReader getIs(){
        return this.is;
    }
    

    
    public void resetState(){
        this.cards.clear();
        this.cardsMsg.clear();
        this.isBusted=false;
        this.betChips=0;
    }

	public boolean getIsOut() {
		// TODO Auto-generated method stub
		if(getGuesses() == 0)
		{
			return true;
		}
		return false;
	}
    
}
