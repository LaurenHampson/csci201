package assignment4;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Scanner;
import java.util.Vector;

public class HangmanClient extends Thread {
	private Socket socket;
	private BufferedReader is;
	private PrintWriter os;
	private Scanner sc;
	private String name;
	private String pass;
	public static Vector<String> configFile = new Vector<String>();
	public static Vector<String> configFile1 = new Vector<String>();
	public static Vector<String> configWords = new Vector<String>();
	public static String ServerHostname = null;
	public static String ServerPort = null;
	public static String DBConnection = null;
	public static String DBUsername = null;
	public static String DBPassword = null;
	public static String SecretWordFile = null;
	public static WordGenerator wordGenerator = null;
	private int wins;
	private int losses;
	public int numPlayers = 0;
	public String gameName;
	public static ServerOutput so;
	public static int playerCount = 0;

	private Socket s;

	public HangmanClient(Socket _socket, BufferedReader _is, PrintWriter _os) {
		this.socket = _socket;
		this.is = _is;
		this.os = _os;
		sc = new Scanner(System.in);
	}

	public String login(String username, String password) throws SQLException, IOException {
		String answer = JDBCDriver.getUser(username, password, this.DBConnection, this.DBUsername, this.DBPassword);
		//System.out.println(answer);
		// so.m1(username, password);
		return answer;
	}

	public void createAccount(String username, String password) throws IOException {
		JDBCDriver.addUser(username, password, 0, 0, this.DBConnection, this.DBUsername, this.DBPassword);
		System.out.println("Great! You are now logged in as " + username + "!");
		// so.m5(username, password);
	}

// 

	public void initializeGame() throws IOException, SQLException {
		int input;
		String name = null, response = null, password = null;
		boolean isGameCreator = false;
		// Dealing with game options
		boolean userFound = false;
		boolean createNew = false;
		String userName = "";

		System.out.println("Please choose from the option below\n1) Start Game\n2) Join Game");
		do {
			input = sc.nextInt();
			sc.nextLine();
		} while (input < 1 || input > 2);
		this.os.println(input);

		// Dealing with noOfPlayers
		if (input == 1) {
			isGameCreator = true;
			System.out.println("Please choose the number of players in the game (1-4)");
			do {
				input = sc.nextInt();
				sc.nextLine();
			} while (input < 1 || input > 4);
			this.os.println(input);
		}

		// Dealing with gameName
		while (!userFound) {
			System.out.print("Username: ");
			userName = sc.nextLine();
			System.out.print("Password: ");
			this.pass = sc.nextLine();
			String ans = login(userName, this.pass);
			if (ans.equals("notFound")) {
				System.out.println("No account exists with those credentials.");
				// so.m3(userName);
				System.out.println("Would you like to create an account with those credentials?");
				System.out.println("1: Yes.  2: No.");
				int choice = sc.nextInt();
				if (choice == 1) {
					createAccount(userName, this.pass);
					createNew = true;
					userFound = true;
					losses = JDBCDriver.getUserLosses(userName, this.DBConnection, this.DBUsername, this.DBPassword);
					wins = JDBCDriver.getUserWins(userName, this.DBConnection, this.DBUsername, this.DBPassword);

					System.out.println(userName + "'s Record");
					System.out.println("-----------------------");
					System.out.println("Wins - " + wins);
					System.out.println("Losses - " + losses);

					this.name = name;
				} else {
					userFound = false;
				}

			}
			if (ans.equals("noPass")) {
				System.out.println("Incorrect password for username: " + userName + ". Please try again.");
				// so.m4(userName);
			}
			if (ans.equals("success")) {
				System.out.println("Great! You are now logged in as " + userName + "!");
				userFound = true;
				losses = JDBCDriver.getUserLosses(userName, this.DBConnection, this.DBUsername, this.DBPassword);
				wins = JDBCDriver.getUserWins(userName, this.DBConnection, this.DBUsername, this.DBPassword);

				System.out.println(userName + "'s Record");
				System.out.println("-----------------------");
				System.out.println("Wins - " + wins);
				System.out.println("Losses - " + losses);

				this.name = name;
				// so.m2(userName);
			}

		}
		// print record here
	
		this.name = name;
		do {
			try {
				if (!isGameCreator) {
					// this.os.println("7");
					System.out.println("Please enter the name of the game you wish to join");

				} else
					System.out.println("Please choose a name for your game");

				gameName = sc.nextLine();
				this.os.println(gameName);
				response = this.is.readLine();
				if (response.equals("Invalid name!")) {
					if (!isGameCreator)
						System.err.println("Invalid choice! There is no on going games with this name");
					else
						System.out.println("Invalid choice! This game has alrady taken by another user");
				}
			} catch (Exception ex) {
				System.err.println("Error! reading gameName from server");
			}

		} while (response.equals("Invalid name!"));
		do {
			try {

				this.os.println(this.name);
				response = this.is.readLine();

			} catch (Exception ex) {
				System.err.println("Error! reading gameName from server");
			}

		} while (response.equals("Invalid name!"));
		this.name = userName;

//		} while (response.equals("Invalid name!"));

		JDBCDriver.addPlayerToGame(gameName, userName, this.DBConnection, this.DBUsername, this.DBPassword);

		// Dealing with playerName

		// this is true if user selet option 1 (start new game)
		if (!isGameCreator) {
			// this message is displayed to players whoe join the game
			System.out.println("The game will start shortly, Waiting for other players to join...");
		} else {
			// This message is displayed to payers who start the game
			response = this.is.readLine();
			System.out.println(response);
		}
	}

	private void startGame() throws IOException {
		String request, response, name, chips;
		int bet = 0;
		// Waiting for other players, when players are complete server send a message to
		// start game
		boolean gameOver = false;
		//response = this.is.readLine();
		
			System.out.println("Determining secret word...");
		

		while (gameOver == false) {
			response = this.is.readLine();

			if ("secretWord".equals(response)) {
				response = this.is.readLine();
				System.out.println(response);
			}
//			
			if ("your turn!".equals(response)) {
				// System.out.println("It's your turn to guess!");
				response = this.is.readLine();
				if ("guessOut".equals(response)) {
					response = this.is.readLine();
					System.out.println(response);
				}


				System.out.println("1) Guess a Letter");
				System.out.println("2) Guess a Word");
				System.out.print("What would you like to do?  ");
				do {
					request = this.sc.nextLine();
				} while (!(request.equals("1") || request.equals("2")));
				this.os.println(request);// sending user choise to server
				// response = this.is.readLine();
			}
			if (response.equals("letterQuery")) {
				System.out.print("Letter to guess - ");
				request = this.sc.nextLine();
				this.os.println(request);
				response = this.is.readLine();
				System.out.println(response);
			}
			if(response.equals("wordQuery"))
				{
					System.out.print("What is the word? ");
					request = this.sc.nextLine();
					this.os.println(request);
					
				}

			if ("end!".equals(response)) {
				response = this.is.readLine();
				System.out.println(response);
				response = this.is.readLine();
				System.out.println(response);
				response = this.is.readLine();
				gameOver = true;
			
				if("loss".equals(response))
				{
					JDBCDriver.addLoss(this.name, this.pass,this.DBConnection, this.DBUsername, this.DBPassword);
				}
				
				if("win".equals(response))
				{
					JDBCDriver.addWin(this.name, this.pass,this.DBConnection, this.DBUsername, this.DBPassword);
				}

				losses = JDBCDriver.getUserLosses(this.name, this.DBConnection, this.DBUsername, this.DBPassword);
				wins = JDBCDriver.getUserWins(this.name, this.DBConnection, this.DBUsername, this.DBPassword);

				System.out.println(this.name + "'s Record");
				System.out.println("-----------------------");
				System.out.println("Wins - " + wins);
				System.out.println("Losses - " + losses);
				
				System.out.println("Thank you for playing Hangman!");
			}

		}

	}

	public static void main(String[] args) throws IOException, SQLException {
		System.out.println("Welcome to Hangman!");
		// prompt the user to enter the configuration file
		System.out.println("What is the name of the configuration file? ");
		Scanner scan = new Scanner(System.in);
		String configFilename = scan.nextLine();
		FileReader fr = null;
		BufferedReader br = null;

		// open the config file and read the parameters !!!!! to do --> use the
		// "properties" class
		try {
			fr = new FileReader(configFilename);
			br = new BufferedReader(fr);
			String line = br.readLine();
			while (line != null) {
				configFile.add(line);
				line = br.readLine();
			}
			for (int i = 0; i < configFile.size(); i++) {
				String ss = configFile.get(i);
				String[] parts = ss.split("=");
				configFile1.add(parts[0]); // before the equals
				configFile1.add(parts[1]); // after the equals
			}
		} catch (FileNotFoundException fnfe) {
			System.out.println(fnfe.getMessage());
		} catch (IOException ioe) {
			System.out.println(ioe.getMessage());
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException ioe) {
					System.out.println(ioe.getMessage());
				}
			}
			if (fr != null) {
				try {
					fr.close();
				} catch (IOException ioe) {
					System.out.println(ioe.getMessage());
				}
			}
		}
		// look for what is missing, ask the user to enter a configuration file with
		// that format
		for (int i = 0; i < configFile1.size(); i++) {
			if (configFile1.get(i).equals("ServerHostname")) {
				ServerHostname = configFile1.get(i + 1);
			}
			if (configFile1.get(i).equals("ServerPort")) {
				ServerPort = configFile1.get(i + 1);
			}
			if (configFile1.get(i).equals("DBConnection")) {
				DBConnection = configFile1.get(i + 1);
			}
			if (configFile1.get(i).equals("DBUsername")) {
				DBUsername = configFile1.get(i + 1);
			}
			if (configFile1.get(i).equals("DBPassword")) {
				DBPassword = configFile1.get(i + 1);
			}
			if (configFile1.get(i).equals("SecretWordFile")) {
				SecretWordFile = configFile1.get(i + 1);
			}
		}

		boolean missing = false;
		if (ServerHostname == null || ServerPort == null || DBConnection == null || DBUsername == null
				|| DBPassword == null || SecretWordFile == null) {

			if (ServerHostname == null) {
				System.out.println("ServerHostname is a required parameter in the configuration file");
				missing = true;
			}
			if (ServerPort == null) {
				System.out.println("ServerPort is a required parameter in the configuration file");
				missing = true;

			}
			if (DBConnection == null) {
				System.out.println("DBConnection is a required parameter in the configuration file");
				missing = true;
			}
			if (DBUsername == null) {
				System.out.println("DBUsername is a required parameter in the configuration file");
				missing = true;

			}
			if (DBPassword == null) {
				System.out.println("DBPassword is a required parameter in the configuration file");
				missing = true;

			}
			if (SecretWordFile == null) {
				System.out.println("SecretWordFile is a required parameter in the configuration file");
				missing = true;
			}
		}

		// add how to get the correct configuration file here

		// if anything is missing terminate the program
		if (missing == true) {
			scan.close();
			// return;
			System.exit(0); // ask about this
		}

		// if the configuration file is correct
		// output all of the parameters

		System.out.println("Server Hostname - " + ServerHostname);
		System.out.println("Server Port - " + ServerPort);
		System.out.println("Database Connection String - " + DBConnection);
		System.out.println("Database Username - " + DBUsername);
		System.out.println("Database Password - " + DBPassword);
		System.out.println("Secret Word File - " + SecretWordFile);

		// JDBCDriver.initialConnect(DBConnection, DBUsername, DBPassword);

		// JDBC code to add the words to the database
		// select a random word each time
		fr = null;
		br = null;

		try {
			fr = new FileReader(SecretWordFile);
			br = new BufferedReader(fr);
			String line = br.readLine();
			while (line != null) {
				configWords.add(line);
				line = br.readLine();
			}

			wordGenerator = new WordGenerator(configWords);

			// add code for adding the words here
			// JDBCDriver.addWords(configWords, DBConnection, DBUsername, DBPassword);

//				
		} catch (FileNotFoundException fnfe) {
			System.out.println(fnfe.getMessage());
		} catch (IOException ioe) {
			System.out.println(ioe.getMessage());
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException ioe) {
					System.out.println(ioe.getMessage());
				}
			}
			if (fr != null) {
				try {
					fr.close();
				} catch (IOException ioe) {
					System.out.println(ioe.getMessage());
				}
			}
		}

		if (configWords.isEmpty()) {
			// Output that the configuration file is empty and unable to get a word
		}
		String[] pa = ServerPort.split(" ");
		ServerPort = pa[0];
		int port = Integer.parseInt(ServerPort); // comes from config file
		String[] hn = ServerHostname.split(" ");
		ServerHostname = hn[0];
		Socket clientSocket = null;
		try {
			System.out.print("Trying to connect to server... ");
			clientSocket = new Socket(ServerHostname, port);
			System.out.println("Connected!");

		} catch (IOException ioe) {
			System.out.println("Unable to connect to server " + ServerHostname + "on port " + port + ".");
		}

		BufferedReader is = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
		PrintWriter os = new PrintWriter(clientSocket.getOutputStream(), true);

		// Creating game instance
		HangmanClient HangmanClient = new HangmanClient(clientSocket, is, os);
		so = new ServerOutput(clientSocket);
		HangmanClient.initializeGame();
		HangmanClient.startGame();

		clientSocket.close();

	}
}
