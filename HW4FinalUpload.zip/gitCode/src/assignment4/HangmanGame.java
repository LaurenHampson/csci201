/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment4;

import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author master
 */
public class HangmanGame extends Thread {
	private final ArrayList<HangmanPlayer> playerList;
	private final int noOfPlayers;
	private final String gameName;
	public String word = "";
	public ArrayList<String> letters = null;
	public boolean GameOver = false;
	public boolean wordFound = false;
	public boolean noGuess = false;
	private boolean isGameEnd;
	public boolean notWord = false;

	HangmanGame(int _noOfPlayers, String _gameName, String w) {
		this.playerList = new ArrayList<>();
		this.noOfPlayers = _noOfPlayers;
		this.gameName = _gameName;
		this.word = w;
		this.isGameEnd = false;
		this.letters = new ArrayList<String>();

	}

	@Override
	public void run() {

		this.completePlayers();// first complete players for the game
		this.startGame();

	}

	private void completePlayers() {
		
		do {
			try {
				// System.out.println(this.playerList.size()+":"+this.noOfPlayers);
				sleep(1000);
			} catch (InterruptedException ex) {
				System.err.println(ex.getMessage());
			}
		} while (this.playerList.size() < this.noOfPlayers);

		// Sending message to players when game players are complete
		// System.out.println("In complete");
		this.sendMessageToAll("Let the game commence. Good luck to all players!");


	}

	public String wordPrint(String w) {
		String ret = "";

		if (!letters.isEmpty()) {
			ret = "";
			boolean inLetters = false;
			for (int x = 0; x < w.length(); x++) {
				inLetters = false;
				for (int i = 0; i < letters.size(); i++) {
					if (w.substring(x, x + 1).equals(letters.get(i))) {
						ret = ret + letters.get(i).toUpperCase() + " ";
						inLetters = true;
						break;
					}
				}
				if (inLetters == false) {
					ret = ret + "_ ";
				}

			}
		} else {
			for (int i = 0; i < w.length(); i++) {

				ret = ret + "_ ";
			}
		}
		return ret;
	}

	// This procedure hold our whole gmane logic
	private void startGame() {

		try {
			this.startRounds();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	private void makeLetterGuess(String letter) throws NumberFormatException, IOException {

		boolean letterFound = false;

		for (int x = 0; x < this.word.length(); x++) {
			if (word.substring(x, x + 1).equals(letter)) {
				letters.add(letter);
				letterFound = true;

			}
		}
		if (letterFound == true) {
			this.sendMessageToAll("The letter '" + letter + "' is in the secret word!");
			String newWord = wordPrint(word);
			String[] nw = newWord.split(" ");
			String check = "";
			for (int i = 0; i < nw.length; i++) {
				check = check + nw[i];
			}
			if (check.toLowerCase().equals(word)) {
				this.wordFound = true;
				// user wins!
			} else {
				this.sendMessageToAll("secretWord");
				this.sendMessageToAll("Secret Word: " + newWord);
			}
		}
		if (letterFound == false) {
			this.playerList.get(0).setGuesses();
			this.sendMessageToAll("The letter '" + letter + "' is not in the secret word!");
			String newWord = wordPrint(word);
			this.sendMessageToAll("secretWord");
			this.sendMessageToAll("Secret Word: " + newWord);
			if (this.playerList.get(0).getGuesses() == 0) {
				this.noGuess = true;
			}

		}

		// this.sendMessageToAll("your turn!");

	}

	private void makeWordGuess(String wordG) throws NumberFormatException, IOException {

		if (wordG.toLowerCase().equals(word)) {
			this.wordFound = true;
		} else {
			this.notWord = true;
		}

		// this.sendMessageToAll("your turn!");

	}

	// Performs rounds throughout the game until one player loses all their chips
	private void startRounds() throws IOException {
		boolean stay = false;// user to exit from loop and end taking new cards

		String request = null;
		String _word = this.word;

		String w = "abc";
		w = wordPrint(_word);
		//System.out.println(w);
		this.sendMessageToAll("secretWord");
		this.sendMessageToAll("Secret Word: " + w);

//       

		while (GameOver == false) {
			stay = false;

			if (this.wordFound == true) {
				this.sendMessageToAll("end!");

				this.sendMessageToAll("That is correct! You win!");
				this.sendMessageToAll("The Secret Word is " + word + "!");

				GameOver = true;
				this.sendMessageToAll("win");
				break;
			} else if (this.noGuess == true) {
				this.sendMessageToAll("end!");
				this.sendMessageToAll("You are out of guesses. You lose.  The secret word was: " + word + ".");
				GameOver = true;
				this.sendMessageToAll("loss");
				break;
			} else if (this.notWord == true) {
				this.sendMessageToAll("end!");
				this.sendMessageToAll("You guessed incorrectly. You lose.  The secret word was: " + word + ".");
				GameOver = true;
				this.sendMessageToAll("loss");
				break;
			} else {
				this.sendMessageToAll("your turn!");
				this.sendMessageToAll("guessOut");
				this.sendMessageToAll(
						"You have " + this.playerList.get(0).getGuesses() + " incorrect guesses remaining.");

				this.sendMessageToAllExcept("It's " + this.playerList.get(0).getName() + " turn to guess!", 0);

				// do {
				request = this.playerList.get(0).getIs().readLine();
				if (request.equals("1")) {
					this.sendMessageToAll("letterQuery");
					String letter = this.playerList.get(0).getIs().readLine();
					makeLetterGuess(letter);

				} else if (request.equals("2")) {
					this.sendMessageToAll("wordQuery");
					String wordG = this.playerList.get(0).getIs().readLine();
					makeWordGuess(wordG);
					// add code for guessing a word

					stay = true;
				}
			}
		}

		this.sendMessageToAll("end!");
	}

	// healper function for sending any meggesge to game players
	private void sendMessageToAll(String _msg) {
		for (int i = 0; i < this.noOfPlayers; ++i) {
			this.playerList.get(i).sendMessage(_msg);
		}
	}

	private void sendMessageToAllExcept(String _msg, int _i) {// _i => user whome to not send message
		for (int i = 0; i < this.noOfPlayers; ++i) {
			if (i != _i) {
				this.playerList.get(i).sendMessage("message!");
				this.playerList.get(i).sendMessage(_msg);
			}
		}
	}

	// healper function for sending status to game players
	private void sendStatusToAll(String _msg) {
		for (int i = 0; i < this.noOfPlayers; ++i) {
			this.playerList.get(i).sendMessage("status!");
			this.playerList.get(i).sendStatus(_msg);
		}
	}

	public void addPlayer(HangmanPlayer _player) {
		this.playerList.add(_player);
	}

	public boolean checkPlayerNameAvailability(String _name) {
		for (int i = 0; i < this.playerList.size(); ++i) {
			if (playerList.get(i).getName().equals(_name))
				return false;// if name is already taken by another player
		}

		return true;// if name not exist
	}

	// it will reset cards of deck
	public void resetPlayersState() {
		for (int i = 0; i < this.noOfPlayers + 1; ++i) {
			this.playerList.get(i).resetState();
		}
	}

	public boolean getIsGameEnd() {
		return this.isGameEnd;
	}

	public void sendMessageToCreator(String _msg) {
		this.playerList.get(0).sendMessage("message!");
		this.playerList.get(0).sendMessage(_msg + " Joined the game");
	}
}
