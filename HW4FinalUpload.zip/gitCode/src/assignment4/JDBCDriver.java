package assignment4;

import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCDriver {
	private static Connection conn = null;
	private static ResultSet rs = null;
	private static Statement st = null;
	private static PreparedStatement ps = null;
	private static String db = null;
	private static String u = null;
	private static String p = null;

	public static void initialConnect(String database, String user, String pass) {
		try {
			System.out.print("Trying to connect to database...");
			Class.forName("com.mysql.cj.jdbc.Driver"); // for version 5 get rid of the .cj

			conn = DriverManager.getConnection(database + "?user=" + user + "&password=" + pass + "&useSSL=false");

			System.out.println("Connected!");
			db = database;
			u = user;
			p = pass;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Unable to connect to database " + database + " with username " + user + " and password "
					+ pass + ".");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Unable to connect to database " + database + " with username " + user + " and password "
					+ pass + ".");
		}
	}

	public static void connect(String database, String user, String pass) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver"); // for version 5 get rid of the .cj

			conn = DriverManager.getConnection(database + "?user=" + user + "&password=" + pass + "&useSSL=false");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void close() {
		try {
			if (rs != null) {
				rs.close();
				rs = null;
			}
			if (conn != null) {
				conn.close();
				conn = null;
			}
			if (ps != null) {
				ps = null;
			}
		} catch (SQLException sqle) {
			System.out.println("connection close error");
			sqle.printStackTrace();
		}
	}

	public static void addUser(String user, String password, int wins, int losses, String db, String u, String p) {
		connect(db, u, p);
		try {

			System.out.println("Connected database successfully...");
			ps = conn.prepareStatement("INSERT INTO Users (_username, _password, _wins, _losses) VALUES ('" + user
					+ "', '" + password + "', '" + wins + "', '" + losses + "');");
			ps.executeUpdate();

			//System.out.println("Inserted in try1");
		} catch (SQLException e) {
			System.out.println("SQLException in function \"addUser\"");
			e.printStackTrace();
		} finally {
			close();
		}

	}

	public static String getUser(String user, String pass, String db, String u, String p) throws SQLException {
		connect(db, u, p);
		ResultSet rs = null;
		
			ps = conn.prepareStatement("SELECT * from Users where _username='" + user + "'");
			rs = ps.executeQuery();
			if (!rs.next()) {
				
				return "notFound";
			} else {
				
					String username = rs.getString("_username");
					System.out.println(username);
					String password = rs.getString("_password");
					System.out.println(password);
					if (!password.equals(pass)) {
						
						return "noPass";
					} else {
						
						return "success";
					}
				
			}
		
		

	}

	public static int getUserWins(String user, String db, String u, String p) {
		connect(db, u, p);
		ResultSet rs = null;
		int wins = 0;
		try {

			ps = conn.prepareStatement("SELECT * from Users where _username='" + user + "'");
			rs = ps.executeQuery();

			while (rs.next()) {
				wins = rs.getInt("_wins");
				return wins;
			}

		} catch (SQLException e) {
			System.out.println("SQLException in function \"addWords\"");
			e.printStackTrace();
		} finally {
			close();
		}
		return wins;

	}

	public static int getUserLosses(String user, String db, String u, String p) {
		connect(db, u, p);
		ResultSet rs = null;
		int losses = 0;
		try {

			ps = conn.prepareStatement("SELECT * from Users where _username='" + user + "'");
			rs = ps.executeQuery();

			while (rs.next()) {
				losses = rs.getInt("_losses");
				return losses;
			}

		} catch (SQLException e) {
			System.out.println("SQLException in function \"addWords\"");
			e.printStackTrace();
		} finally {
			close();
		}
		return losses;

	}

	public static boolean findGame(String gameName, String db, String u, String p) {
		connect(db, u, p);
		ResultSet rs = null;
		boolean found = false;
		try {

			ps = conn.prepareStatement("SELECT * from Games where _gameName='" + gameName + "'");
			rs = ps.executeQuery();

			if(!rs.next())
			{
				return false;
			}
			else
			{
				return true;
			}
			

		} catch (SQLException e) {
			System.out.println("SQLException in function \"addWords\"");
			e.printStackTrace();
		} finally {
			close();
		}
		return found;

	}
	public static boolean isFull(String gameName, int num, String db, String u, String p) {
		connect(db, u, p);
		ResultSet rs = null;
		boolean found = false;
		try {

			ps = conn.prepareStatement("SELECT * from Games where _gameName='" + gameName + "'");
			rs = ps.executeQuery();
			int count = 0;
			System.err.println(rs.getFetchSize());
			while(rs.next())
			{
				count ++;
			}
			if(count< num)
			{
				System.err.println(count);
				System.err.println(num);
				return true;
			}
			else
			{
				System.err.println(count);
				System.err.println(num);
				return false;
			}
			
			

		} catch (SQLException e) {
			System.out.println("SQLException in function \"addWords\"");
			e.printStackTrace();
		} finally {
			close();
		}
		return found;

	}
	public static void addPlayerToGame(String game, String user, String db, String u, String p)
	{
		connect(db, u, p);
		try {

			System.out.println("Connected database successfully...");
			ps = conn.prepareStatement("INSERT INTO Games (_gameName, _userName) VALUES ('" + game
					+ "', '" + user + "');");
			ps.executeUpdate();

			System.out.println();
		} catch (SQLException e) {
			System.out.println("SQLException in function \"addUser\"");
			e.printStackTrace();
		} finally {
			close();
		}

		
	}

	public static void addLoss(String user, String pass,String db, String u, String p)
	{
		connect(db, u, p);
		int rs = 0;
		int losses = getUserLosses(user, db, u, p);
		losses = losses+1;
		int wins = getUserWins(user,db,u,p);
		try {

			ps = conn.prepareStatement("DELETE FROM Users WHERE _username = '" + user + "'");
			ps.executeUpdate();
			System.out.println("Update executed");
			
			addUser(user, pass, wins, losses, db, u, p);

		} catch (SQLException e) {
			System.out.println("SQLException in function \"addWords\"");
			e.printStackTrace();
		} finally {
			close();
		}
		
	}
	public static void addWin(String user, String pass,String db, String u, String p)
	{
		connect(db, u, p);
		int rs = 0;
		int wins = 0;
		wins+= getUserWins(user, db, u, p);
		wins = wins+1;
		int losses = getUserLosses(user, db, u, p);

		try {
			ps = conn.prepareStatement("DELETE FROM Users WHERE _username = '" + user + "'");
			ps.executeUpdate();
			System.out.println("Update executed");
			
			addUser(user, pass, wins, losses, db, u, p);
		

		} catch (SQLException e) {
			System.out.println("SQLException in function \"addWords\"");
			e.printStackTrace();
		} finally {
			close();
		}
		
	}
}

