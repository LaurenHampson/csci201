package assignment4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

public class HangmanClub {
	private ServerSocket serverSocket;
	private HashMap<String, HangmanGame> gamesContainer; // gamesContainer stores all running games
	public String DBConnection;
	public String DBUsername;
	public String DBPassword;
	public String gameWord;

	public HangmanClub(ServerSocket _serverSocket, String DBC, String DBU, String DBP, String gameW) {
		this.serverSocket = _serverSocket;
		this.gamesContainer = new HashMap<>();
		this.DBConnection = DBC;
		this.DBUsername = DBU;
		this.DBPassword = DBP;
		this.gameWord = gameW;
	}

	/*
	 * this is our main thread and is always available to welcome new connection
	 */
	public void openClub() throws IOException {
		while (true) {
			new HandleNewPlayer(serverSocket.accept(), this.DBConnection, this.DBUsername, this.DBPassword, gameWord)
					.run();// listining to client and assign it to the handler
		}
	}

	/*
	 * This function has responsibility of handling new players and also
	 * creating/joning the game.
	 */
	private class HandleNewPlayer extends Thread {
		private Socket socket;// This socket belongs to new client
		BufferedReader is;// input from socket
		PrintWriter os;// output to socket
		public String DBConnection;
		public String DBUsername;
		public String DBPassword;
		public String gameWord;
		public int numPlayers = 0;

		public HandleNewPlayer(Socket _socket, String DBC, String DBU, String DBP, String word) throws IOException {
			this.socket = _socket;
			this.is = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			this.os = new PrintWriter(socket.getOutputStream(), true);
			this.DBConnection = DBC;
			this.DBUsername = DBU;
			this.DBPassword = DBP;
			this.gameWord = word;
		}

		public boolean checkName(String game) {
			boolean exists = JDBCDriver.findGame(game, this.DBConnection, this.DBUsername, this.DBPassword);
			return exists;
		}

		public boolean isFull(String game, int num) {
			boolean full = JDBCDriver.isFull(game, num, this.DBConnection, this.DBUsername, this.DBPassword);
			return full;
		}

		@Override
		public void run() {
			try {
				String msg = this.is.readLine();
				if (msg.equals("1")) {
					this.startNewGame();
				//	System.out.println(msg);
				} else {
					this.joinTheGame();
				//	System.out.println(msg);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		
		private void startNewGame() throws IOException {
		
			
			String gameName;
			boolean gameExists;
			int noOfPlayers = Integer.parseInt(this.is.readLine());// reading no of players from client
			this.numPlayers = noOfPlayers;
			// This loop ensure the uniquenes of gameName
			do {
				gameName = this.is.readLine();

				gameExists = checkName(gameName);
				
				if (gameExists == true) {
					this.os.println("Invalid name!");
				}
				
			

			} while (gameExists == true);

			gamesContainer.put(gameName, new HangmanGame(noOfPlayers, gameName, this.gameWord));
			HangmanGame g = new HangmanGame(noOfPlayers, gameName, this.gameWord);
			this.os.println("Game created!");// Sending response to client that game is created (game creator)
			String playerName = this.is.readLine();// reading name of client (game creator)
			this.os.println("name available!");// as it is the first player in the game
			//gamesContainer.get(gameName).addPlayer(new HangmanPlayer(playerName, this.socket, this.os, this.is));
			g.addPlayer(new HangmanPlayer(playerName, this.socket, this.os, this.is));
			this.os.println("Waiting for " + (noOfPlayers - 1) + " other players to join...");
			g.start();// Starting thread for new game
			
		}

		private void joinTheGame() throws IOException {
			System.out.println("Joining game method");
			String gameName;
            String playerName;
            boolean isNameAvailable;
            //This loop ensure the valid name of gameName
            do{
                gameName=this.is.readLine();
                
                isNameAvailable=gamesContainer.containsKey(gameName);
                System.out.println(isNameAvailable);
                if(!isNameAvailable)//if game not exist
                    this.os.println("Invalid name!");//sending invalid response to client (game creator)
            }while(!isNameAvailable);
            
            this.os.println("Game available!");
            HangmanGame game=gamesContainer.get(gameName);
            //This loop ensure the valid name of player
            do{
                playerName=this.is.readLine();
                isNameAvailable=game.checkPlayerNameAvailability(playerName);
                if(!isNameAvailable)//if game not exist
                    this.os.println("Invalid name!");//sending invalid response to client (game creator)
            }while(!isNameAvailable);
            
            this.os.println("name available!");
            game.addPlayer(new HangmanPlayer(playerName, this.socket, this.os, this.is));//adding player to game
            game.sendMessageToCreator(playerName);
            game.start();
	        }
	
		}
	

	}

