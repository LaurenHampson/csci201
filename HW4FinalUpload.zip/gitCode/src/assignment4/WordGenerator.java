package assignment4;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.ArrayList;
import java.util.Random;
import java.util.Vector;


public class WordGenerator
{


	private static Vector<String> wordList;
	private static Random rand;

	
	



	public WordGenerator(Vector<String> words)
	{
            this.rand=new Random();
            this.wordList = words;
           
	}



	public static String getRandomWord() {
		int num = 0;

		num = rand.nextInt(wordList.size());

		String wordChosen = wordList.get(num);

		wordChosen = wordChosen.toLowerCase();
		System.err.println(wordChosen);

		return wordChosen;
	}

}
