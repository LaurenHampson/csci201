package assignment4;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Vector;


public class ServerOutput {
	public OutputStream os = null;
	public OutputStreamWriter osw = null;
    public BufferedWriter bw = null;
	public ServerOutput(Socket s) throws IOException
	{
		this.os = s.getOutputStream();
		this.osw = new OutputStreamWriter(os);
         this.bw = new BufferedWriter(osw);
	}
	public String getDateTime()
	{
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss.SSS");
    	Timestamp timestamp = new Timestamp(System.currentTimeMillis());
    	String timeOut = sdf.format(timestamp);
    	return timeOut;
	}
	
	
	public void m1(String username, String password) throws IOException
	{
		String output = getDateTime() + ": " + username + " - trying to log in with password " + password + ".";
		bw.write(output);
		bw.flush();
//		this.oos.writeObject(output);
//		this.oos.flush();
	}
	public void m2(String username) throws IOException
	{
		String output = getDateTime() + ": " + username + " - successfully logged in.";
		bw.write(output);
		bw.flush();
//		this.oos.writeObject(output);
//		this.oos.flush();
	}
	public void m3(String username) throws IOException
	{
		String output = getDateTime() + ": " + username + " - does not have an account so not successfully logged in.";
		bw.write(output);
		bw.flush();
//		this.oos.writeObject(output);
//		this.oos.flush();
	}
	public void m4(String username) throws IOException
	{
		String output = getDateTime() + ": " + username + " - has an account but not successfully logged in.";
		bw.write(output);
		bw.flush();
//		this.oos.writeObject(output);
//		this.oos.flush();
	}
	public void m5(String username, String password) throws IOException
	{
		String output = getDateTime() + ": " + username + " - created an account with password " + password + "." ;
		bw.write(output);
		bw.flush();
//		this.oos.writeObject(output);
//		this.oos.flush();
	}
	public void m6(String username, int wins, int losses) throws IOException
	{
		String output = getDateTime() + ": " + username + " - has record " + wins + " wins and " + losses + " losses.";
		bw.write(output);
		bw.flush();
//		this.oos.writeObject(output);
//		this.oos.flush();
	}
	public void m7(String username, String gameName) throws IOException
	{
		String output = getDateTime() + ": " + username + " - wants to start a game called " + gameName + "." ;
		bw.write(output);
		bw.flush();
//		this.oos.writeObject(output);
//		this.oos.flush();
	}
	public void m8(String username, String gameName) throws IOException
	{
		String output = getDateTime() + ": " + username + " - wants to join a game called " + gameName + "." ;
		bw.write(output);
		bw.flush();
//		this.oos.writeObject(output);
//		this.oos.flush();
	}
	public void m9(String username, String gameName) throws IOException
	{
		String output = getDateTime() + ": " + username + " - " + gameName + " already exists, so unable to start " + gameName + ". ";
		bw.write(output);
		bw.flush();
//		this.oos.writeObject(output);
//		this.oos.flush();
	}
	public void m10(String username, String gameName) throws IOException
	{
		String output = getDateTime() + ": " + username + " - successfully started game " + gameName + "." ;
		bw.write(output);
		bw.flush();
//		this.oos.writeObject(output);
//		this.oos.flush();
	}
	public void m11(String username, String gameName) throws IOException
	{
		String output = getDateTime() + ": " + username + " - successfully joined game " + gameName + "." ;
		bw.write(output);
		bw.flush();
		//		this.oos.writeObject(output);
//		this.oos.flush();
	}
	public void m12(String username, String gameName) throws IOException
	{
		
		String output = getDateTime() + ": " + username + " - " + gameName + " exists, but " + username + " unable to join game because maximum number of players have already joined " + gameName + "." ;
		bw.write(output);
		bw.flush();
//		this.oos.writeObject(output);
//		this.oos.flush();
	}
	public void m13(String username, int num, String gameName) throws IOException
	{
		String output = getDateTime() + ": " + username + " - " + gameName + " needs " + num + " to start game." ;
		bw.write(output);
		bw.flush();
//		this.oos.writeObject(output);
//		this.oos.flush();
	}
	public void m14(String username, int num, String gameName, String secretWord) throws IOException
	{
		String output = getDateTime() + ": " + username + " - " + gameName + " has " + num + " so starting game.  Secret word is " + secretWord + ".";
		bw.write(output);
		bw.flush();
//		this.oos.writeObject(output);
//		this.oos.flush();
	}
	public void m15(String username, String gameName, String letter) throws IOException
	{
		String output = getDateTime() + ": " + gameName + " " + username + " - guessed letter " + letter;
		bw.write(output);
		bw.flush();
//		this.oos.writeObject(output);
//		this.oos.flush();
	}
	public void m16(String username, String gameName, String letter, Vector<Integer> positions, String display, String secretWord) throws IOException
	{
		String output = getDateTime() + ": " + gameName + " " + username + " - letter is in " + secretWord +" in position(s) ";
		for(int i = 0 ; i < positions.size(); i++)
		{
			output = output + positions.get(i);
			if(i+1<positions.size())
			{
				output = output+", ";
			}
			else {
				output = output+". ";
			}
		}
		output = output + "Secret word now shows " + display + ".";
		bw.write(output);
		bw.flush();
//		this.oos.writeObject(output);
//		this.oos.flush();
	}
	public void m17(String username, String letter, String secretWord, String gameName, int guesses) throws IOException
	{
		String output = getDateTime() + ": " + gameName + " " + username + " - " + letter + " is not in " + secretWord + ". " + gameName + " now has " + guesses + " guesses remaining.";
		bw.write(output);
		bw.flush();
//		this.oos.writeObject(output);
//		this.oos.flush();
	}
	public void m18(String username, String gameName, String wordGuess) throws IOException
	{
		String output = getDateTime() + ": " + gameName + " " + username + " - guessed word" +  wordGuess + ". ";
		bw.write(output);
		bw.flush();
//		this.oos.writeObject(output);
//		this.oos.flush();
	}
	public void m19(String username, String gameName, String wordGuess) throws IOException
	{
		String output = getDateTime() + " : " + gameName + " " + username + " - " + wordGuess + " is incorrect. " + username + " has lost and is no longer in the game.";
		bw.write(output);
		bw.flush();
//		this.oos.writeObject(output);
//		this.oos.flush();
	}
	public void m20(String username, String gameName, String wordGuess, Vector<String> users) throws IOException
	{
		String output = getDateTime() + " : " + gameName + " " + username + " - " + wordGuess + " is correct. " + username + " wins game.";
		for(int i = 0 ; i < users.size(); i++)
		{
			output = output + users.get(i);
			if(i+1<users.size())
			{
				output = output+", ";
			}
			
		}
		output = output + " have lost the game." ;
		bw.write(output);
		bw.flush();
//		this.oos.writeObject(output);
//		this.oos.flush();
	}
	
	
    	
}
