DROP DATABASE if exists Assignment4;
CREATE DATABASE Assignment4;
USE Assignment4;


CREATE TABLE Users(
    _username VARCHAR(50) PRIMARY KEY NOT NULL,
    _password VARCHAR(200) NOT NULL,
    _wins INT(11) NOT NULL,
    _losses INT(11) NOT NULL
);


CREATE TABLE Games(
	_gameName VARCHAR(50) PRIMARY KEY NOT NULL,
   _username VARCHAR (70) NOT NULL,
     FOREIGN KEY fk1(_username) REFERENCES Users(_username)
);

